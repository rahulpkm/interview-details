

const onLoad = () => {
    let hhbuilders = [];
    let household = document.createElement('li');
    let btnAdd = document.getElementsByClassName('add');
    let btnSubmit = document.getElementsByTagName('button')[1];

    // Add event handler
    const onAdd = (event) => {
        event.preventDefault();

        const txtAge = document.getElementById('age');
        const ddlRelation = document.getElementById('rel');
        const chkSmoker = document.getElementById('smoker');
        // Get values from control
        const age = document.getElementById('age').value;
        const relation = document.getElementById('rel').value;
        const smoker = document.getElementById('smoker').checked;


        // Validate the age and relationship before adding to collection
        if ((age < 1 || isNaN(age)) && relation === "") {
            alert('Please enter an age greater than 1 and relationship is required')
        } else if (relation === "") {
            alert('Relationship is required');
        } else if (age < 1 || isNaN(age)) {
            alert('Please enter an age greater than 1');
        } else {
            // Created the object to add to the array.
            const hhbuilder = {
                age: age,
                relation: relation,
                isSmoker: smoker
            }
            hhbuilders.push(hhbuilder);
            household.innerHTML = JSON.stringify(hhbuilders);
            document.body.appendChild(household);

            let delBtn = onDelete();
            delBtn.addEventListener('click', () => {
                onRemove(delBtn);
            });
            household.appendChild(delBtn);
            onReset();
        }
    };

    const onSubmit = (event) => {
        event.preventDefault();
        let debug = document.querySelector('.debug');
        debug.innerHTML = JSON.stringify(hhbuilders);
        debug.style.display = "block";
        debug.style.overflow = "auto";
        //Clear the duplicate display
        household.innerHTML = "";
    };

    const onReset = () => {
        document.getElementById('age').value = "";
        document.getElementById('rel').value = "";
        document.getElementById('smoker').checked = false;
    };

    const onRemove = (delBtn) => {
        hhbuilders.pop();
        household.innerHTML = JSON.stringify(hhbuilders);
        //if arry is not empty add delete button
        if (hhbuilders.length > 0) {
            household.appendChild(delBtn);
        }
    };

    const onDelete = () => {
        let btnDelete = document.createElement('button');
        const txt = document.createTextNode('X');
        btnDelete.appendChild(txt);
        return btnDelete;
    };

    btnAdd[0].addEventListener('click', onAdd);
    btnSubmit.addEventListener('click', onSubmit);
}

window.onload = onLoad